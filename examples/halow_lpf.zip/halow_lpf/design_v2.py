#!/usr/bin/env python3
"""HaLow LPF v2 — vendor-bounded optimization + SRF-aware sanity check.

Improvements vs design.py:

  1. ``bound_to_vendor=True`` — optimizer uses differential_evolution
     constrained to the Coilcraft 0402HP / Murata GJM C0G catalog hull,
     so component values are guaranteed realizable. Fixes the L3=0.6nH
     outcome from v1 where the optimizer wandered below the vendor
     minimum.

  2. ``srf_audit`` — after synthesis, every component's SRF is checked
     against the highest spec target. Anything within 30% of SRF gets
     a warning since the analytical model isn't predictive there.

  3. Spec focused on the primary coex concern: HaLow 2H landing in
     LTE B3 DL (1805-1880 MHz). Three closely-spaced targets across
     this band ensure rejection isn't just a notch at one frequency.

Outputs (gitignored):
  - starting_v2.s2p, after_zeros_v2.s2p, with_real_v2.s2p, final_v2.s2p
  - response_v2.png, report_v2.md
"""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np

from mcp_ltspice.asc_io import generate_lpf_asc
from mcp_ltspice.eval import FilterSpec, evaluate_filter_spec
from mcp_ltspice.extract import (
    components_dict_to_elements,
    ladder_sparams_from_components,
)
from mcp_ltspice.find_zeros import find_transmission_zeros
from mcp_ltspice.montecarlo import monte_carlo_analysis
from mcp_ltspice.optimize import optimize_filter
from mcp_ltspice.render import render_response
from mcp_ltspice.srf_check import srf_audit
from mcp_ltspice.sweep import sensitivity_analysis
from mcp_ltspice.synthesis import (
    Topology,
    place_transmission_zero,
    synthesize_lc_lpf,
)
from mcp_ltspice.vendor_models import substitute_real_components
from rf_mcp_common.touchstone import network_to_touchstone

HERE = Path(__file__).parent
SPEC_PATH = HERE / "spec_v2.json"


def _write_s2p(components: dict[str, float], path: Path, *, transmission_zeros: bool = True) -> Path:
    f = np.geomspace(10e6, 5e9, 1001)
    elements = components_dict_to_elements(
        components, topology="series_first", transmission_zeros=transmission_zeros,
    )
    s = ladder_sparams_from_components(elements, f, z0=50.0)
    return network_to_touchstone(f, s, path, z0=50.0)


def _print_check(label: str, result) -> None:
    print(f"\n=== {label} ({result.overall.upper()}) ===")
    print(f"{'Criterion':<36} {'Target':>10} {'Measured':>12} {'Margin':>10} {'Status':>8}")
    for c in result.criteria:
        target = f"{c.target_db:.1f} dB"
        measured = f"{c.measured_db:.2f} dB" if math.isfinite(c.measured_db) else "n/a"
        margin = f"{c.margin_db:+.2f} dB" if math.isfinite(c.margin_db) else "n/a"
        print(f"{c.label:<36} {target:>10} {measured:>12} {margin:>10} {c.status:>8}")


def main() -> None:
    spec = FilterSpec.model_validate(json.loads(SPEC_PATH.read_text()))
    print(f"Spec loaded: {SPEC_PATH.name}")
    print(f"  Primary concern: HaLow 2H -> LTE B3 DL (1805-1880 MHz)")

    # 1. Synthesize 9th-order elliptic prototype
    print("\n[1] Synthesizing 9th-order elliptic LPF (fc=1.0 GHz)")
    design = synthesize_lc_lpf(
        "elliptic", order=9, cutoff_hz=1.0e9,
        ripple_db=0.1, stopband_atten_db=50,
        z0=50.0, topology=Topology.SERIES_FIRST,
    )
    starting = _write_s2p(design.components, HERE / "starting_v2.s2p")
    print(f"   {len(design.components)} components -> {starting.name}")

    # 2. Place zeros at coex targets - prioritize the LTE B3 DL band
    print("\n[2] Placing 4 transmission zeros across LTE B3 DL + GPS L1 + 3H")
    zero_targets = [
        (2, 1.575e9),    # GPS L1 protection
        (4, 1.81e9),     # LTE B3 DL low (2H of HaLow ch 905)
        (6, 1.86e9),     # LTE B3 DL high (2H of HaLow ch 930)
        (8, 2.745e9),    # 3H mid
    ]
    comps = dict(design.components)
    for trap_idx, freq in zero_targets:
        result = place_transmission_zero(
            comps, trap_index=trap_idx, target_freq_hz=freq,
            preserve_ratio=True, snap_series=None,
        )
        comps = result["components"]
        print(
            f"   Trap L{trap_idx}/C{trap_idx} -> {freq/1e9:.3f} GHz "
            f"(achieved {result['achieved_freq_hz']/1e9:.3f} GHz, "
            f"err {result['freq_error_pct']:+.2f}%)"
        )
    after_zeros = _write_s2p(comps, HERE / "after_zeros_v2.s2p")
    check_zeros = evaluate_filter_spec(after_zeros, spec)
    _print_check("After zero placement (ideal components)", check_zeros)

    # 3. Substitute real Coilcraft + Murata parts
    print("\n[3] Substituting Coilcraft 0402HP + Murata GJM C0G")
    parts = substitute_real_components(comps)
    real_comps = {ref: info["snapped_value"] for ref, info in parts.items()}
    real_s2p = _write_s2p(real_comps, HERE / "with_real_v2.s2p")
    check_real = evaluate_filter_spec(real_s2p, spec)
    _print_check("With real parts (no optimization yet)", check_real)

    # 4. SRF audit BEFORE optimization
    print("\n[4a] SRF audit before optimization")
    audit_pre = srf_audit(real_comps, spec)
    print(f"   severity={audit_pre['severity']}, {audit_pre['n_flagged']}/{audit_pre['n_components']} flagged")
    for w in audit_pre["warnings"][:5]:
        print(f"   ! {w}")

    # 5. Optimize WITH vendor bounds — guarantees realizable values
    print("\n[5] Optimizing with bound_to_vendor=True (differential_evolution)")
    print("    Component values constrained to Coilcraft 0402HP + Murata GJM C0G catalog")
    opt = optimize_filter(
        real_comps, spec,
        transmission_zeros=True, z0=50.0,
        max_iter=800,
        bound_to_vendor=True,
        inductor_vendor="coilcraft_0402hp",
        capacitor_vendor="murata_gjm_c0g",
        passband_weight=15.0,
    )
    print(f"   loss: {opt.initial_loss:.3f} -> {opt.final_loss:.3f}")
    final_comps = opt.snapped_components
    print("   Final BOM (all from vendor catalog):")
    for ref in sorted(final_comps.keys()):
        delta = (final_comps[ref] - real_comps[ref]) / real_comps[ref] * 100
        print(f"     {ref}: {final_comps[ref]:.3e} ({delta:+.1f}% from initial)")
    final_s2p = _write_s2p(final_comps, HERE / "final_v2.s2p")
    asc = generate_lpf_asc(
        final_comps, HERE / "final_v2.asc",
        topology="lpf_t_elliptic", z0=50.0,
        f_start_hz=10e6, f_stop_hz=5e9,
    )
    print(f"   --> {final_s2p.name}, {asc.name}")
    check_final = evaluate_filter_spec(final_s2p, spec)
    _print_check("FINAL (vendor-bounded, all values purchasable)", check_final)

    # 6. SRF audit AFTER optimization
    print("\n[6] SRF audit on final design")
    audit_post = srf_audit(final_comps, spec)
    print(f"   severity={audit_post['severity']}, {audit_post['n_flagged']}/{audit_post['n_components']} flagged")
    if audit_post["warnings"]:
        print("   Warnings (analytical rejection at these freqs may not match measurement):")
        for w in audit_post["warnings"]:
            print(f"     ! {w}")
    else:
        print("   All components have SRF comfortably above the highest spec target.")

    # 7. Verify achieved transmission zeros
    found_zeros = find_transmission_zeros(final_s2p, min_depth_db=15)
    print("\n[7] Achieved transmission zeros:")
    for z in found_zeros:
        print(f"     {z['freq_hz']/1e9:.3f} GHz, depth {z['depth_db']:.1f} dB, Q~={z['q_factor']:.0f}")

    # 8. Sensitivity analysis - which components are tolerance-critical?
    print("\n[8] Sensitivity ranking (top 5 most influential components)")
    sens = sensitivity_analysis(
        final_comps, spec, perturbation_pct=2.0,
        transmission_zeros=True,
    )
    ranked = list(sens["per_component_total_sensitivity"].items())[:5]
    for comp, total in ranked:
        print(f"   {comp}: total sensitivity = {total:.3f} dB / %")
    print(f"   --> tighten tolerance grade on '{sens['most_influential_component']}' first")

    # 9. Render Bode plot with primary-concern markers
    png = render_response(
        final_s2p, HERE / "response_v2.png",
        markers=[
            (928e6, "passband edge"),
            (1575e6, "GPS L1"),
            (1810e6, "B3 DL low"),
            (1840e6, "B3 DL mid (2H worst)"),
            (1860e6, "B3 DL high"),
            (1960e6, "B25 DL"),
            (2440e6, "ISM 2.4G"),
            (2745e6, "3H mid"),
        ],
        title="HaLow LPF v2 -- vendor-bounded, focused on LTE B3 DL 2H protection",
    )
    print(f"\n[9] Response plot --> {png.name}")

    # 10. Monte Carlo at 2% tolerance
    print("\n[10] Monte Carlo yield (2% tolerance, 1000 runs)")
    mc = monte_carlo_analysis(
        final_comps, spec,
        tolerance_pct=2.0, n_runs=1000,
        transmission_zeros=True, n_jobs=-1,
    )
    print(f"   yield: {mc.yield_pct:.1f}% ({mc.n_passing}/{mc.n_runs})")
    if mc.failing_criteria_counts:
        for label, count in sorted(mc.failing_criteria_counts.items(), key=lambda kv: -kv[1])[:5]:
            print(f"     - {label}: {count} fails ({100*count/mc.n_runs:.1f}%)")

    # 11. Write report
    report_path = HERE / "report_v2.md"
    _write_report(
        report_path, check_real, check_final, audit_pre, audit_post,
        sens, mc, final_comps, parts, found_zeros,
    )
    print(f"\n[11] Wrote report --> {report_path.name}")

    print(f"\n{'='*70}")
    print(f"FINAL VERDICT: {check_final.overall.upper()}")
    print(f"Vendor-bound:  YES (all values in Coilcraft 0402HP / Murata GJM C0G)")
    print(f"SRF severity:  {audit_post['severity']}")
    print(f"MC yield (2%): {mc.yield_pct:.1f}%")
    print(f"{'='*70}")


def _write_report(path, check_real, check_final, audit_pre, audit_post, sens, mc, comps, parts, zeros) -> None:
    lines = [
        "# HaLow LPF v2 — Final Design Report",
        "",
        "Vendor-bounded optimization with SRF-aware audit. Designed primarily",
        "to protect LTE B3 DL (1805-1880 MHz) from HaLow 2nd-harmonic emission.",
        "",
        "## Final BOM (every value purchasable)",
        "",
        "| Refdes | Initial vendor pick | Final after opt | SRF | Flagged? |",
        "|---|---|---|---|---|",
    ]
    for ref in sorted(comps.keys()):
        info = parts.get(ref, {})
        initial = info.get("snapped_value", "—")
        final_val = comps[ref]
        srf = info.get("srf_hz", None)
        flag = audit_post["per_component"].get(ref, {}).get("flagged", False)
        ini_str = f"{initial:.3e}" if isinstance(initial, (int, float)) else str(initial)
        srf_str = f"{srf/1e9:.2f} GHz" if srf else "—"
        lines.append(
            f"| {ref} | {ini_str} | {final_val:.3e} | {srf_str} | "
            f"{'⚠ YES' if flag else 'no'} |"
        )
    lines.append("")

    lines.append("## SRF audit summary")
    lines.append("")
    lines.append(f"- **Severity (final):** {audit_post['severity']}")
    lines.append(f"- **Flagged components:** {audit_post['n_flagged']}/{audit_post['n_components']}")
    lines.append(f"- **Highest spec target:** {audit_post['max_spec_target_hz']/1e6:.0f} MHz")
    if audit_post["warnings"]:
        lines.append("")
        lines.append("Warnings:")
        for w in audit_post["warnings"]:
            lines.append(f"- {w}")
    lines.append("")

    lines.append("## Spec compliance — final design")
    lines.append("")
    lines.append("| Criterion | Target | Measured | Margin | Status |")
    lines.append("|---|---|---|---|---|")
    for c in check_final.criteria:
        m = f"{c.measured_db:+.2f} dB" if math.isfinite(c.measured_db) else "n/a"
        margin = f"{c.margin_db:+.2f} dB" if math.isfinite(c.margin_db) else "n/a"
        status = "✅ PASS" if c.status == "pass" else "❌ FAIL"
        lines.append(f"| {c.label} | {c.target_db:.1f} dB | {m} | {margin} | {status} |")
    lines.append(f"\n**Overall: {check_final.overall.upper()}**")
    lines.append("")

    lines.append("## Sensitivity ranking (top-5 components by total influence)")
    lines.append("")
    lines.append("| Component | Total sensitivity (dB / %) |")
    lines.append("|---|---|")
    for comp, total in list(sens["per_component_total_sensitivity"].items())[:5]:
        lines.append(f"| {comp} | {total:.3f} |")
    lines.append(
        f"\n**Tighten tolerance on `{sens['most_influential_component']}` first** "
        f"if yield needs improvement."
    )
    lines.append("")

    lines.append("## Monte Carlo yield (2% tolerance, 1000 trials)")
    lines.append("")
    lines.append(f"- **Yield: {mc.yield_pct:.1f}%** ({mc.n_passing} / {mc.n_runs})")
    if mc.failing_criteria_counts:
        lines.append("\nFailing criteria:")
        for label, count in sorted(mc.failing_criteria_counts.items(), key=lambda kv: -kv[1]):
            lines.append(f"- {label}: {count} ({100*count/mc.n_runs:.1f}%)")
    lines.append("")

    lines.append("## Achieved transmission zeros")
    lines.append("")
    lines.append("| Frequency | Depth | Q |")
    lines.append("|---|---|---|")
    for z in zeros:
        lines.append(f"| {z['freq_hz']/1e9:.3f} GHz | {z['depth_db']:.1f} dB | {z['q_factor']:.0f} |")
    lines.append("")

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
