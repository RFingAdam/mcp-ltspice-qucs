# HaLow LPF v2 — Final Design Report

Vendor-bounded optimization with SRF-aware audit. Designed primarily
to protect LTE B3 DL (1805-1880 MHz) from HaLow 2nd-harmonic emission.

## Final BOM (every value purchasable)

| Refdes | Initial vendor pick | Final after opt | SRF | Flagged? |
|---|---|---|---|---|
| C2 | 1.800e-12 | 3.300e-12 | 5.31 GHz | ⚠ YES |
| C4 | 1.000e-12 | 3.300e-12 | 7.12 GHz | ⚠ YES |
| C6 | 5.000e-13 | 1.000e-12 | 10.07 GHz | no |
| C8 | 2.200e-11 | 2.700e-12 | 1.28 GHz | no |
| L1 | 8.200e-09 | 6.800e-09 | 3.10 GHz | ⚠ YES |
| L2 | 5.600e-09 | 2.200e-09 | 4.00 GHz | no |
| L3 | 1.000e-08 | 1.200e-08 | 2.60 GHz | ⚠ YES |
| L4 | 6.800e-09 | 2.200e-09 | 3.50 GHz | no |
| L5 | 6.800e-09 | 1.000e-08 | 3.50 GHz | ⚠ YES |
| L6 | 1.200e-08 | 1.500e-09 | 2.30 GHz | no |
| L7 | 1.200e-08 | 1.500e-09 | 2.30 GHz | no |
| L8 | 1.000e-09 | 3.300e-09 | 11.80 GHz | no |
| L9 | 1.500e-08 | 6.800e-09 | 2.00 GHz | ⚠ YES |

## SRF audit summary

- **Severity (final):** critical
- **Flagged components:** 6/13
- **Highest spec target:** 2745 MHz

Warnings:
- L1 = 6.800e-09 (coilcraft_0402hp) has SRF 3.50 GHz — within 30.0% of the highest spec target (2.75 GHz). Analytical rejection at high frequencies will not match measurement.
- C2 = 3.300e-12 (murata_gjm_c0g) has SRF 3.74 GHz — within 30.0% of the highest spec target (2.75 GHz). Analytical rejection at high frequencies will not match measurement.
- L3 = 1.200e-08 (coilcraft_0402hp) has SRF 2.30 GHz — within 30.0% of the highest spec target (2.75 GHz). Analytical rejection at high frequencies will not match measurement.
- C4 = 3.300e-12 (murata_gjm_c0g) has SRF 3.74 GHz — within 30.0% of the highest spec target (2.75 GHz). Analytical rejection at high frequencies will not match measurement.
- L5 = 1.000e-08 (coilcraft_0402hp) has SRF 2.60 GHz — within 30.0% of the highest spec target (2.75 GHz). Analytical rejection at high frequencies will not match measurement.
- L9 = 6.800e-09 (coilcraft_0402hp) has SRF 3.50 GHz — within 30.0% of the highest spec target (2.75 GHz). Analytical rejection at high frequencies will not match measurement.

## Spec compliance — final design

| Criterion | Target | Measured | Margin | Status |
|---|---|---|---|---|
| Passband IL | 0.5 dB | +0.31 dB | +0.19 dB | ✅ PASS |
| Passband RL | 15.0 dB | +11.59 dB | -3.41 dB | ❌ FAIL |
| GPS L1 (FCC restricted) | 30.0 dB | +63.41 dB | +33.41 dB | ✅ PASS |
| LTE B3 DL low (2H of HaLow ch3) | 50.0 dB | +98.87 dB | +48.87 dB | ✅ PASS |
| LTE B3 DL mid (2H worst) | 55.0 dB | +110.40 dB | +55.40 dB | ✅ PASS |
| LTE B3 DL high (2H upper) | 50.0 dB | +130.30 dB | +80.30 dB | ✅ PASS |
| LTE B25/B2 DL (adjacent to 2H) | 45.0 dB | +87.65 dB | +42.65 dB | ✅ PASS |
| ISM 2.4G mid (BLE/WiFi coex) | 30.0 dB | +48.20 dB | +18.20 dB | ✅ PASS |
| 3H mid (mostly clear band) | 35.0 dB | +49.55 dB | +14.55 dB | ✅ PASS |

**Overall: FAIL**

## Sensitivity ranking (top-5 components by total influence)

| Component | Total sensitivity (dB / %) |
|---|---|
| C2 | 5.814 |
| C4 | 5.683 |
| L2 | 5.347 |
| L4 | 5.323 |
| L8 | 3.262 |

**Tighten tolerance on `C2` first** if yield needs improvement.

## Monte Carlo yield (2% tolerance, 1000 trials)

- **Yield: 0.0%** (0 / 1000)

Failing criteria:
- Passband RL: 1000 (100.0%)

## Achieved transmission zeros

| Frequency | Depth | Q |
|---|---|---|
| 1.685 GHz | 117.7 dB | 80 |
| 1.873 GHz | 139.3 dB | 80 |
| 4.098 GHz | 105.9 dB | 53 |

