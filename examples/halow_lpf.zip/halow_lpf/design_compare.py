#!/usr/bin/env python3
"""Compare 5th / 7th / 9th order HaLow LPF designs side-by-side.

For each order:
  1. Synthesize elliptic prototype (fc=1.0 GHz, 0.1 dB ripple, 50 dB stopband)
  2. Place transmission zeros at primary coex targets
  3. Substitute Coilcraft 0402HP + Murata GJM C0G real parts
  4. Optimize with bound_to_vendor=True (DE over vendor catalog)
  5. SRF audit
  6. Monte Carlo at 2% component tolerance, 1000 trials

Then compare on shippable-design metrics:
  - All criteria pass?
  - MC yield ≥ 80%?
  - SRF severity ok / caution / critical?
  - Component count + worst-case sensitivity

Outputs:
  - 5th_order_final.s2p / .asc / .png
  - 7th_order_final.s2p / .asc / .png
  - 9th_order_final.s2p / .asc / .png
  - compare_report.md  (the side-by-side table)
"""

from __future__ import annotations

import json
import math
from pathlib import Path

import numpy as np

from mcp_ltspice.asc_io import generate_lpf_asc
from mcp_ltspice.eval import FilterSpec, evaluate_filter_spec
from mcp_ltspice.extract import (
    components_dict_to_elements,
    ladder_sparams_from_components,
)
from mcp_ltspice.find_zeros import find_transmission_zeros
from mcp_ltspice.montecarlo import monte_carlo_analysis
from mcp_ltspice.optimize import optimize_filter
from mcp_ltspice.render import render_response
from mcp_ltspice.srf_check import srf_audit
from mcp_ltspice.sweep import sensitivity_analysis
from mcp_ltspice.synthesis import (
    Topology,
    place_transmission_zero,
    synthesize_lc_lpf,
)
from mcp_ltspice.vendor_models import substitute_real_components
from rf_mcp_common.touchstone import network_to_touchstone

HERE = Path(__file__).parent
SPEC_PATH = HERE / "spec_shippable.json"


def _write_s2p(components, path: Path) -> Path:
    f = np.geomspace(10e6, 5e9, 1001)
    elements = components_dict_to_elements(
        components, topology="series_first", transmission_zeros=True,
    )
    s = ladder_sparams_from_components(elements, f, z0=50.0)
    return network_to_touchstone(f, s, path, z0=50.0)


def design_one(order: int, spec: FilterSpec, *, out_prefix: str) -> dict:
    """Synthesize → zero-place → vendor-substitute → optimize → audit one order."""
    print(f"\n{'='*70}\n  ORDER {order}\n{'='*70}")

    # 1. Synthesize the prototype.
    design = synthesize_lc_lpf(
        "elliptic", order=order, cutoff_hz=1.0e9,
        ripple_db=0.1, stopband_atten_db=50,
        z0=50.0, topology=Topology.SERIES_FIRST,
    )
    n_traps = (order - 1) // 2
    print(f"  {len(design.components)} components, {n_traps} transmission zeros")

    # 2. Zero placement priority (limited by available trap count):
    #    1. LTE B3 DL mid (1.84 GHz)        - the primary 2H concern
    #    2. LTE B3 DL low edge (1.81 GHz)   - widens the B3 DL notch
    #    3. GPS L1 (1.575 GHz)              - FCC restricted band
    #    4. NA 3H (2.745 GHz)               - LTE B41/B7 area
    all_targets = [
        (1.84e9, "LTE B3 DL mid"),
        (1.81e9, "LTE B3 DL low"),
        (1.575e9, "GPS L1"),
        (2.745e9, "NA 3H"),
    ]
    targets = all_targets[:n_traps]   # take as many as we have traps for
    comps = dict(design.components)
    for trap_local_idx, (freq, label) in enumerate(targets):
        # Trap refdes index: L2/C2 = trap 0, L4/C4 = trap 1, etc.
        trap_index = 2 * (trap_local_idx + 1)
        result = place_transmission_zero(
            comps, trap_index=trap_index, target_freq_hz=freq,
            preserve_ratio=True, snap_series=None,
        )
        comps = result["components"]
        print(
            f"  Zero {trap_local_idx+1}: {label:>20} -> {freq/1e9:.3f} GHz "
            f"(achieved {result['achieved_freq_hz']/1e9:.3f} GHz, "
            f"err {result['freq_error_pct']:+.2f}%)"
        )

    # 3. Vendor-substitute
    parts = substitute_real_components(comps)
    real_comps = {ref: info["snapped_value"] for ref, info in parts.items()}

    # 4. Vendor-bounded optimization with passband emphasis
    print(f"  Optimizing (bound_to_vendor=True, passband_weight=30, max_iter=1500)...")
    opt = optimize_filter(
        real_comps, spec,
        transmission_zeros=True, z0=50.0,
        max_iter=1500,
        bound_to_vendor=True,
        inductor_vendor="coilcraft_0402hp",
        capacitor_vendor="murata_gjm_c0g",
        passband_weight=30.0,
    )
    final_comps = opt.snapped_components
    print(f"  loss: {opt.initial_loss:.2f} -> {opt.final_loss:.2f}")

    # 5. Eval + SRF audit + MC
    final_s2p = _write_s2p(final_comps, HERE / f"{out_prefix}.s2p")
    asc = generate_lpf_asc(
        final_comps, HERE / f"{out_prefix}.asc",
        topology="lpf_t_elliptic", z0=50.0,
    )
    check = evaluate_filter_spec(final_s2p, spec)
    audit = srf_audit(final_comps, spec)
    sens = sensitivity_analysis(
        final_comps, spec, perturbation_pct=2.0, transmission_zeros=True,
    )
    mc = monte_carlo_analysis(
        final_comps, spec,
        tolerance_pct=2.0, n_runs=1000,
        transmission_zeros=True, n_jobs=-1,
    )
    found_zeros = find_transmission_zeros(final_s2p, min_depth_db=15)

    # Render plot
    render_response(
        final_s2p, HERE / f"{out_prefix}.png",
        markers=[
            (928e6, "passband edge"),
            (1575e6, "GPS L1"),
            (1840e6, "B3 DL 2H worst"),
            (1960e6, "B25 DL"),
            (2440e6, "ISM 2.4G"),
            (2745e6, "NA 3H"),
        ],
        title=f"HaLow LPF — order {order}, vendor-bounded, "
              f"{'PASS' if check.overall == 'pass' else 'FAIL'}",
    )

    # Print spec table
    print(f"\n  Spec compliance:")
    print(f"  {'Criterion':<36} {'Target':>8} {'Measured':>10} {'Margin':>9} {'Status':>6}")
    for c in check.criteria:
        m = f"{c.measured_db:+.2f}" if math.isfinite(c.measured_db) else "n/a"
        margin = f"{c.margin_db:+.2f}" if math.isfinite(c.margin_db) else "n/a"
        print(f"  {c.label:<36} {c.target_db:>6.1f} dB {m:>9} dB {margin:>7} dB {c.status:>6}")
    print(f"\n  Overall: {check.overall.upper()}")
    print(f"  SRF severity: {audit['severity']} ({audit['n_flagged']}/{audit['n_components']} flagged)")
    print(f"  MC yield (2%): {mc.yield_pct:.1f}%")
    print(f"  Most-influential component: {sens['most_influential_component']}")

    return {
        "order": order,
        "n_components": len(final_comps),
        "n_traps_used": n_traps,
        "components": final_comps,
        "spec_overall": check.overall,
        "criteria": [
            {
                "label": c.label, "target_db": c.target_db,
                "measured_db": c.measured_db, "margin_db": c.margin_db,
                "status": c.status,
            }
            for c in check.criteria
        ],
        "srf_severity": audit["severity"],
        "n_srf_flagged": audit["n_flagged"],
        "mc_yield_pct": mc.yield_pct,
        "mc_failures": dict(mc.failing_criteria_counts),
        "most_sensitive": sens["most_influential_component"],
        "transmission_zeros": [
            {"freq_hz": z["freq_hz"], "depth_db": z["depth_db"]} for z in found_zeros
        ],
        "files": {
            "s2p": str(final_s2p.name),
            "asc": str(asc.name),
            "png": f"{out_prefix}.png",
        },
    }


def shippable_score(result: dict) -> tuple[int, str]:
    """Higher = more shippable. Returns (score, rationale)."""
    score = 0
    reasons = []

    if result["spec_overall"] == "pass":
        score += 100
        reasons.append("all criteria pass")
    else:
        # Partial credit per-criterion
        n_pass = sum(1 for c in result["criteria"] if c["status"] == "pass")
        score += n_pass * 5
        reasons.append(f"{n_pass}/{len(result['criteria'])} criteria pass")

    # MC yield
    yield_pct = result["mc_yield_pct"]
    score += int(yield_pct)
    if yield_pct >= 90:
        reasons.append(f"yield {yield_pct:.0f}% (excellent)")
    elif yield_pct >= 80:
        reasons.append(f"yield {yield_pct:.0f}% (production-acceptable)")
    elif yield_pct >= 50:
        reasons.append(f"yield {yield_pct:.0f}% (marginal)")
    else:
        reasons.append(f"yield {yield_pct:.0f}% (NOT production-acceptable)")

    # SRF
    sev = result["srf_severity"]
    if sev == "ok":
        score += 30
        reasons.append("SRF: no concerns")
    elif sev == "caution":
        score += 15
        reasons.append("SRF: 1-2 components near limit")
    else:
        reasons.append(f"SRF: {result['n_srf_flagged']} components flagged (critical)")

    # Component count penalty (cost / area / sensitivity)
    n_comp = result["n_components"]
    score -= n_comp * 2     # each component costs ~2 score units
    reasons.append(f"{n_comp} components")

    return score, " | ".join(reasons)


def main() -> None:
    spec = FilterSpec.model_validate(json.loads(SPEC_PATH.read_text()))
    print(f"Spec: {SPEC_PATH.name}")
    print(f"  Passband IL ≤ {spec.passband.il_max_db} dB, RL ≥ {spec.passband.rl_min_db} dB")
    print(f"  {len(spec.stopband_targets)} stopband targets")

    results = []
    for order in (5, 7, 9):
        results.append(design_one(order, spec, out_prefix=f"{order}th_order_final"))

    # Score and pick winner
    print(f"\n{'='*70}\n  COMPARISON\n{'='*70}\n")
    scored = [(r, *shippable_score(r)) for r in results]
    scored.sort(key=lambda t: -t[1])
    winner = scored[0][0]

    print(f"{'Order':<8}{'Components':<12}{'Overall':<10}{'MC yield':<11}{'SRF':<11}{'Score':<8}")
    print("-" * 70)
    for r, score, _ in scored:
        marker = " <-- WINNER" if r is winner else ""
        print(
            f"{r['order']:<8}{r['n_components']:<12}{r['spec_overall']:<10}"
            f"{r['mc_yield_pct']:>6.1f}%   {r['srf_severity']:<11}{score}{marker}"
        )

    print(f"\nMost shippable: ORDER {winner['order']}")
    print(f"  -> {scored[0][2]}")

    # Write the comparison report
    _write_compare_report(HERE / "compare_report.md", results, winner, scored)
    print(f"\nReport written: compare_report.md")


def _write_compare_report(path, results, winner, scored) -> None:
    lines = [
        "# HaLow LPF — Order Comparison",
        "",
        "Three vendor-bounded designs at orders 5, 7, 9, evaluated against",
        f"the production-realistic spec at `spec_shippable.json`.",
        "",
        "## Summary",
        "",
        "| Order | Components | Spec | MC yield (2%) | SRF | Score |",
        "|---|---|---|---|---|---|",
    ]
    for r, score, reasons in scored:
        marker = " ← shippable" if r is winner else ""
        lines.append(
            f"| **{r['order']}{'  ' + marker if r is winner else ''}** | "
            f"{r['n_components']} | "
            f"{r['spec_overall']} | "
            f"{r['mc_yield_pct']:.1f}% | "
            f"{r['srf_severity']} | "
            f"{score} |"
        )
    lines.append("")
    lines.append(f"**Recommendation: order {winner['order']}**")
    lines.append("")
    lines.append("## Per-order detail")
    lines.append("")

    for r in results:
        lines.append(f"### Order {r['order']}")
        lines.append("")
        lines.append(f"- **Components:** {r['n_components']} ({r['n_traps_used']} transmission-zero traps)")
        lines.append(f"- **Overall:** {r['spec_overall']}")
        lines.append(f"- **MC yield (2% tol):** {r['mc_yield_pct']:.1f}%")
        lines.append(f"- **SRF:** {r['srf_severity']} ({r['n_srf_flagged']} components flagged)")
        lines.append(f"- **Files:** `{r['files']['s2p']}`, `{r['files']['asc']}`, `{r['files']['png']}`")
        lines.append("")
        lines.append("**Final BOM:**")
        lines.append("")
        lines.append("| Refdes | Value |")
        lines.append("|---|---|")
        for ref in sorted(r["components"].keys()):
            v = r["components"][ref]
            unit = "nH" if ref.startswith("L") else "pF"
            scaled = v * (1e9 if ref.startswith("L") else 1e12)
            lines.append(f"| {ref} | {scaled:.3g} {unit} |")
        lines.append("")
        lines.append("**Spec compliance:**")
        lines.append("")
        lines.append("| Criterion | Target | Measured | Margin | Status |")
        lines.append("|---|---|---|---|---|")
        for c in r["criteria"]:
            m = f"{c['measured_db']:+.2f}" if math.isfinite(c["measured_db"]) else "n/a"
            margin = f"{c['margin_db']:+.2f}" if math.isfinite(c["margin_db"]) else "n/a"
            status = "✅ pass" if c["status"] == "pass" else "❌ fail"
            lines.append(f"| {c['label']} | {c['target_db']:.1f} dB | {m} dB | {margin} dB | {status} |")
        lines.append("")
        if r["mc_failures"]:
            lines.append("**MC failure breakdown:**")
            lines.append("")
            for label, count in sorted(r["mc_failures"].items(), key=lambda kv: -kv[1]):
                lines.append(f"- {label}: {count} ({count/10:.1f}%)")
            lines.append("")
        lines.append("**Achieved transmission zeros:**")
        lines.append("")
        lines.append("| Frequency | Depth |")
        lines.append("|---|---|")
        for z in r["transmission_zeros"]:
            lines.append(f"| {z['freq_hz']/1e9:.3f} GHz | {z['depth_db']:.1f} dB |")
        lines.append("")
        lines.append("---")
        lines.append("")

    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()
