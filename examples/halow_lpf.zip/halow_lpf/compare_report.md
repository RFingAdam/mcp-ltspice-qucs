# HaLow LPF — Order Comparison

Three vendor-bounded designs at orders 5, 7, 9, evaluated against
the production-realistic spec at `spec_shippable.json`.

## Summary

| Order | Components | Spec | MC yield (2%) | SRF | Score |
|---|---|---|---|---|---|
| **7   ← shippable** | 10 | pass | 100.0% | critical | 180 |
| **9** | 13 | pass | 100.0% | critical | 174 |
| **5** | 7 | fail | 0.0% | caution | 31 |

**Recommendation: order 7**

## Per-order detail

### Order 5

- **Components:** 7 (2 transmission-zero traps)
- **Overall:** fail
- **MC yield (2% tol):** 0.0%
- **SRF:** caution (2 components flagged)
- **Files:** `5th_order_final.s2p`, `5th_order_final.asc`, `5th_order_final.png`

**Final BOM:**

| Refdes | Value |
|---|---|
| C2 | 2.7 pF |
| C4 | 2.7 pF |
| L1 | 4.7 nH |
| L2 | 2.2 nH |
| L3 | 12 nH |
| L4 | 2.2 nH |
| L5 | 10 nH |

**Spec compliance:**

| Criterion | Target | Measured | Margin | Status |
|---|---|---|---|---|
| Passband IL | 1.0 dB | +0.30 dB | +0.70 dB | ✅ pass |
| Passband RL | 10.0 dB | +11.70 dB | +1.70 dB | ✅ pass |
| GPS L1 (FCC restricted) | 30.0 dB | +25.78 dB | -4.22 dB | ❌ fail |
| LTE B3 DL low (2H of HaLow ch3) | 45.0 dB | +44.51 dB | -0.49 dB | ❌ fail |
| LTE B3 DL mid (2H worst case) | 50.0 dB | +47.50 dB | -2.50 dB | ❌ fail |
| LTE B3 DL high (2H upper) | 45.0 dB | +49.64 dB | +4.64 dB | ✅ pass |
| LTE B25/B2 DL | 40.0 dB | +63.71 dB | +23.71 dB | ✅ pass |
| ISM 2.4G (BLE/WiFi) | 25.0 dB | +51.11 dB | +26.11 dB | ✅ pass |
| 3H mid | 25.0 dB | +45.42 dB | +20.42 dB | ✅ pass |

**MC failure breakdown:**

- GPS L1 (FCC restricted): 1000 (100.0%)
- LTE B3 DL mid (2H worst case): 1000 (100.0%)
- LTE B3 DL low (2H of HaLow ch3): 791 (79.1%)

**Achieved transmission zeros:**

| Frequency | Depth |
|---|---|
| 2.069 GHz | 124.1 dB |

---

### Order 7

- **Components:** 10 (3 transmission-zero traps)
- **Overall:** pass
- **MC yield (2% tol):** 100.0%
- **SRF:** critical (6 components flagged)
- **Files:** `7th_order_final.s2p`, `7th_order_final.asc`, `7th_order_final.png`

**Final BOM:**

| Refdes | Value |
|---|---|
| C2 | 3.3 pF |
| C4 | 1.5 pF |
| C6 | 2.7 pF |
| L1 | 6.8 nH |
| L2 | 3.3 nH |
| L3 | 8.2 nH |
| L4 | 12 nH |
| L5 | 6.8 nH |
| L6 | 3.3 nH |
| L7 | 6.8 nH |

**Spec compliance:**

| Criterion | Target | Measured | Margin | Status |
|---|---|---|---|---|
| Passband IL | 1.0 dB | +0.37 dB | +0.63 dB | ✅ pass |
| Passband RL | 10.0 dB | +10.91 dB | +0.91 dB | ✅ pass |
| GPS L1 (FCC restricted) | 30.0 dB | +64.78 dB | +34.78 dB | ✅ pass |
| LTE B3 DL low (2H of HaLow ch3) | 45.0 dB | +54.51 dB | +9.51 dB | ✅ pass |
| LTE B3 DL mid (2H worst case) | 50.0 dB | +52.42 dB | +2.42 dB | ✅ pass |
| LTE B3 DL high (2H upper) | 45.0 dB | +51.26 dB | +6.26 dB | ✅ pass |
| LTE B25/B2 DL | 40.0 dB | +47.13 dB | +7.13 dB | ✅ pass |
| ISM 2.4G (BLE/WiFi) | 25.0 dB | +40.15 dB | +15.15 dB | ✅ pass |
| 3H mid | 25.0 dB | +38.91 dB | +13.91 dB | ✅ pass |

**Achieved transmission zeros:**

| Frequency | Depth |
|---|---|
| 1.526 GHz | 99.2 dB |
| 1.685 GHz | 99.4 dB |

---

### Order 9

- **Components:** 13 (4 transmission-zero traps)
- **Overall:** pass
- **MC yield (2% tol):** 100.0%
- **SRF:** critical (5 components flagged)
- **Files:** `9th_order_final.s2p`, `9th_order_final.asc`, `9th_order_final.png`

**Final BOM:**

| Refdes | Value |
|---|---|
| C2 | 3.3 pF |
| C4 | 1.5 pF |
| C6 | 1.5 pF |
| C8 | 2.2 pF |
| L1 | 10 nH |
| L2 | 2.2 nH |
| L3 | 10 nH |
| L4 | 5.6 nH |
| L5 | 5.6 nH |
| L6 | 12 nH |
| L7 | 10 nH |
| L8 | 3.3 nH |
| L9 | 5.6 nH |

**Spec compliance:**

| Criterion | Target | Measured | Margin | Status |
|---|---|---|---|---|
| Passband IL | 1.0 dB | +0.36 dB | +0.64 dB | ✅ pass |
| Passband RL | 10.0 dB | +10.94 dB | +0.94 dB | ✅ pass |
| GPS L1 (FCC restricted) | 30.0 dB | +57.20 dB | +27.20 dB | ✅ pass |
| LTE B3 DL low (2H of HaLow ch3) | 45.0 dB | +103.94 dB | +58.94 dB | ✅ pass |
| LTE B3 DL mid (2H worst case) | 50.0 dB | +114.71 dB | +64.71 dB | ✅ pass |
| LTE B3 DL high (2H upper) | 45.0 dB | +134.42 dB | +89.42 dB | ✅ pass |
| LTE B25/B2 DL | 40.0 dB | +91.79 dB | +51.79 dB | ✅ pass |
| ISM 2.4G (BLE/WiFi) | 25.0 dB | +63.59 dB | +38.59 dB | ✅ pass |
| 3H mid | 25.0 dB | +59.49 dB | +34.49 dB | ✅ pass |

**Achieved transmission zeros:**

| Frequency | Depth |
|---|---|
| 1.190 GHz | 44.0 dB |
| 1.738 GHz | 118.8 dB |
| 1.873 GHz | 143.3 dB |

---

